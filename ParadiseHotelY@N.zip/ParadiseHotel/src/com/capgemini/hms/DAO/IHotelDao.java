package com.capgemini.hms.DAO;

import java.util.List;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;

public interface IHotelDao 
{
 /* public boolean isUserExist(String userId) throws HotelException;
  public Hotel addHotel(Hotel hotel) throws HotelException;
  public Hotel removeHotel(String hotelId) throws HotelException;
  public void  updateHotel(Hotel hotel) throws HotelException;
  public List<RoomDetails> ShowRoomDetails() throws HotelException;
  public  RoomDetails getRoomDetails(String roomId) throws HotelException;
  public void  updateRoomDetails(RoomDetails room) throws HotelException;*/
	
	
	
	public int addHotel(Hotel hotel) throws HotelException;	//Done
	List<Hotel> showAllHotels() throws HotelException;	//Done
	public void updateHotels(Hotel hotel) throws HotelException;	//Done
	List<Hotel> searchHotels(String city) throws HotelException;	//Done
   public void removeHotel(String hotelId) throws HotelException;//Done
   public Hotel getHotelDetails(String hotelId) throws HotelException;


	
	List<RoomDetails> showAllRooms() throws HotelException;	//Done
	public int addRoomDetails(RoomDetails room) throws HotelException;	//Done
	 public void  updateRoomDetails(RoomDetails room) throws HotelException;//Done
	public RoomDetails getRoomDetails(String roomId) throws HotelException;	//Done

	 
		List<BookingDetails> showAllBookings() throws HotelException;	//Done
		public int addBookingDetails(BookingDetails book) throws HotelException;	//Done
		
		
		  public boolean isUserExist(String unm) throws HotelException;
		  public int addUSer(Users user) throws HotelException;	//Done
		  List<Users> showAll() throws HotelException;	//Done
		  public Users getUserDetails(String userId) throws HotelException;		  
		  

}
