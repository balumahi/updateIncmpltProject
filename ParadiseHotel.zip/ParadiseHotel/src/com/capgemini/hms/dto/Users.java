package com.capgemini.hms.dto;

public class Users
{
  private String  userId;
  private  String password;
  private String role;
  private String username;
  private  String mobileNo;
  private String phoneNo;
  private String address;
  private String email;
  
public Users() 
{
	super();
}

public Users(String userId, String password, String role, String username,
		String mobileNo, String phoneNo, String address, String email) {
	super();
	this.userId = userId;
	this.password = password;
	this.role = role;
	this.username = username;
	this.mobileNo = mobileNo;
	this.phoneNo = phoneNo;
	this.address = address;
	this.email = email;
}

public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getMobileNo() {
	return mobileNo;
}

public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Override
public String toString() {
	return "User [userId=" + userId + ", password=" + password + ", role="
			+ role + ", username=" + username + ", mobileNo=" + mobileNo
			+ ", phoneNo=" + phoneNo + ", address=" + address + ", email="
			+ email + "]";
}
  

}
